
function factorial(n) {
    if (n < 0) return "Факториал для отрицательного числа не существует.";
    let result = 1;
    for (let i = 1; i <= n; i++) {
        result *= i;
    }
    return result;
}


function runDemo() {
    const out = document.getElementById("output");

 
    const fact5 = factorial(5);
    const fact0 = factorial(0);
    const factNeg = factorial(-3);  

    
    out.innerHTML = `
        <strong>Результаты:</strong><br><br>
        <strong>factorial(5)</strong> = ${fact5} <br>
        <strong>factorial(0)</strong> = ${fact0} <br>
        <strong>factorial(-3)</strong> = ${factNeg} <br><br>
        <em>Для отрицательных чисел факториал не существует.</em>
    `;
}
